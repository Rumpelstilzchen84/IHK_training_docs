import java.util.Scanner;

public class VorschlagKaffeeMaschineOOP {
    public static void main(String[] args) {
        VorschlagGetraenkeAngebot getraenkeAngebot = new VorschlagGetraenkeAngebot();

        String ueberschrift = "Kaffee-Automat";
        MenueText.ausgeben(ueberschrift);
        System.out.println(getraenkeAngebot.getAnzahlGetraenke() + " verschiedene Getränke stehen zur Auswahl");
        Trennlinie.ausgeben(MenueText.getMenueTextBreite());

        var consoleScanner = new Scanner(System.in);

        int getraenkeWunsch = 0;
        do {
            getraenkeAngebotAnzeigen(getraenkeAngebot);

            // Eingabe auffordern
            System.out.print("Bitte Auswahl treffen (1 - " + getraenkeAngebot.getAnzahlGetraenke() + ") " +
                    "oder \"" + (getraenkeAngebot.getAnzahlGetraenke() + 1) + "\" zum Ausschalten: ");

            // Eingabe prüfen/verarbeiten
            try {
                String eingabe = consoleScanner.nextLine().trim(); // Ganze Zeile (ohne führende und folgende Leerzeichen) einlesen
                if (eingabe.isEmpty()) {
                    System.out.println("Bitte eine Zahl eingeben.");
                    continue;
                }
                getraenkeWunsch = Integer.parseInt(eingabe); // In Zahl umwandeln

                if (getraenkeWunsch >= 1 && getraenkeWunsch <= getraenkeAngebot.getAnzahlGetraenke()) {
                    // Getränk zubereiten
                    getraenkeAngebot.getGetraenke().get(getraenkeWunsch - 1).getraenkAusschenken();

                    // Bisherige Bezüge ausgeben
                    Trennlinie.ausgeben(MenueText.getMenueTextBreite());
                    System.out.println("Bisher zubereitete Getränke an dieser Maschine: " + VorschlagGetraenk.getAnzahlBezuege() + " Stk.");
                    Trennlinie.ausgeben(MenueText.getMenueTextBreite());

                    System.out.println(); // Leerzeile, um Bestellvorgänge optisch voneinander zu trennen

                } else if (getraenkeWunsch == getraenkeAngebot.getAnzahlGetraenke() + 1) {
                    // Ausschalten
                    System.out.println("Kaffeeautomat wird ausgeschaltet...");
                } else {
                    // Falsche Eingabe
                    System.out.println("Ungültige Auswahl. Bitte eine Zahl im angegebenen Bereich eingeben.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Bitte eine gültige Zahl eingeben.");
            }
        } while (getraenkeWunsch != (getraenkeAngebot.getAnzahlGetraenke() + 1));
        consoleScanner.close();
    }

    private static void getraenkeAngebotAnzeigen(VorschlagGetraenkeAngebot getraenkeAngebot) {
        for (int i = 0; i < getraenkeAngebot.getAnzahlGetraenke(); i++) {
            System.out.println((i+1) + ". " + getraenkeAngebot.getGetraenke().get(i).getBezeichnung());
        }
        System.out.println((getraenkeAngebot.getAnzahlGetraenke() + 1) + ". Ausschalten");
    }
}
