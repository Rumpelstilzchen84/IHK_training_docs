import java.util.ArrayList;
import java.util.List;

public class VorschlagGetraenkeAngebot {
    private List<VorschlagGetraenk> getraenke;

    public VorschlagGetraenkeAngebot() {
        /*
        "getraenke" nutzt bisher nur ein Interface,
        weshalb wir hier eine KONKRETE Klasse brauchen (die das Interface implementiert) -> ArrayList<T>
         */
        getraenke = new ArrayList<>();

        getraenke.add(new VorschlagGetraenk("Café Crème",200, 1.0, false));
        getraenke.add(new VorschlagGetraenk("Espresso",50, 0.5, false));
        getraenke.add(new VorschlagGetraenk("Café Cortado", 60, 1.0, true));
        getraenke.add(new VorschlagGetraenk("Cappuccino", 250, 1.5, true));
        getraenke.add(new VorschlagGetraenk("Latte Macchiato", 300, 1.5, true));
    }

    public List<VorschlagGetraenk> getGetraenke() {
        return getraenke;
    }

    public int getAnzahlGetraenke() {
        return getraenke.size();
    }
}
