public class VorschlagGetraenk {
    static int anzahlBezuege;

    private String bezeichnung;
    private int fuellMenge;
    private double bruehZeit;
    private boolean milchSchaum;

    public VorschlagGetraenk(String bezeichnung, int fuellMenge, double bruehZeit, boolean milchSchaum) {
        this.bezeichnung = bezeichnung;
        this.fuellMenge = fuellMenge;
        this.bruehZeit = bruehZeit;
        this.milchSchaum = milchSchaum;
    }

    void getraenkAusschenken() {
        anzahlBezuege++;

        System.out.println(bezeichnung + " zubereitet! Bitte schön!");
        System.out.println("Füllmenge: " + fuellMenge + " ml\n" +
                "Brühzeit: " + bruehZeit + " min\n" +
                (milchSchaum ? "Mit" : "Ohne") + " Milchschaum");
    }

    public static int getAnzahlBezuege() {
        return anzahlBezuege;
    }

    public String getBezeichnung() {
        return bezeichnung;
    }
}
