import java.util.Scanner;

/**
 * @author: Philip Kottmann
 * @Datum: 23. März 2025
 * @Inhalt: Kaffeemaschine in OOP
 */

public class KaffeemaschineOOP {
    public static void main(String[] args) {
        boolean statusAuswahl = true;
        /*
        Wenn ich es richtig verstanden habe, brauchst du diese Variable nur, um die Endlosschleife abbrechen zu können.
        Natürlich ist das so möglich, allerdings könnte es auch direkt in der Schleife,
        ohne die zusätzliche Variable gelöst werden.

        Zusätzlich fehlt hier so bisschen der Kontext. Du deklarierst und initialisiert die Variable,
        dann kommt ganz viel Anderes und dann in der Schleife verwendest du die Variable auf einmal wieder.
        Besser ist es, Variablen immer so nah wie möglich am Verwendungsort (hier Schleife)
        zu deklarieren und initialisieren.
        Wenn du die Variable behalten willst, würde ich also die Deklaration und Initialisierung
        direkt in der Zeile über der Schleife machen. Dann ist der Kontext klarer.

        Den Bezeichner würde ich vermutlich anders wählen. Ich musste erstmal so ein bisschen suchen,
        was eigentlich "statusAuswahl" bewirkt. Code sollte bestenfalls wie ein gutes Buch zu lesen sein,
        ohne Hintergedanken und Interpretationen. Mein Vorschlag für den Bezeichner wäre "isKaffeeMaschineAn"
        oder "isKaffeeMaschineInBetrieb" oder "isKaffeeMaschineEingeschaltet".
        Irgendwas, was so ein bisschen "sprechender" ist, um gleich auf den ersten Blick zu verstehen, worum es geht.
         */

        Getraenk[] getraenkeAngebot = {
                (new Getraenk("Café Crème",200, 1.0, false)),
                (new Getraenk("Espresso",50, 0.5, false)),
                (new Getraenk("Café Cortado", 60, 1.0, true)),
                (new Getraenk("Cappuccino", 250, 1.5, true)),
                (new Getraenk("Latte Macchiato", 300, 1.5, true))};

        /*
        Da du dein Programm "KaffeemaschineOOP" nennst, gehe ich davon aus, dass du OOP üben wolltest.
        An der Stelle würde es sich also (im Sinne von OOP) anbieten, in der main-Methode kein Array von
        Getränken zu erzeugen, sondern die Logik auszulagern in die Klasse "GetraenkeAngebot".
        Mit der Auslagerung kannst du Logik trennen und dadurch die einzelnen Klassen klein und übersichtlich halten.
        Ich würde also statt deines obigen Getränke-Arrays eher folgendes machen:

        GetraenkeAngebot getraenkeAngebot = new GetraenkeAngebot();

        IM Konstruktor der Klasse "GetraenkeAngebot" kannst du dann die einzelnen Getränke erzeugen.
        Mit "getraenkeAngebot.getGetraenke()" könntest du dir dann die Getränke wieder zurückgeben lassen.

        Wir haben bisher Listen noch nicht behandelt, ich würde dir aber empfehlen, statt mit einem
        Array lieber mit einer Liste zu arbeiten. Arrays sind zwar ganz cool, aber in der Praxis wird meist eher mit
        Listen gearbeitet, weil sie einfach deutlich flexibler sind. Gerade bei 5, 10 oder 100 Getränken spielt
        da auch die Performance überhaupt keine Rolle, weil eh alles super schnell geht.
         */

        General.divider();  /* siehe Kommentare direkt in der Klasse "General" */
        System.out.println("============= Kaffee-Automat =============");
        General.divider();
        // Ausgabe der verfügbaren Getränke
        System.out.println(Getraenk.getAnzahlGetraenke() + " verschiedene Getränke stehen zur Auswahl");
        General.divider();

        var consoleScanner = new Scanner(System.in);

        int auswahl = 0;
        /*
        Da die Variable "auswahl" nur innerhalb der Schleife Relevanz hat, würde ich die Variable auch innerhalb
        der Schleife deklarieren und initialisieren (Kontext). Da du die Variable nach der Schleife nicht mehr benötigst,
        ergibt sich (bei einer Deklaration und Initialisierung innerhalb der Schleife) auch kein Problem bezüglich
        Gültigkeitsbereich.
         */

        while (statusAuswahl) {    // Endlosschleife zur Anzeige des Menüs
            // Erstellung der Items im Menü
            for (int i = 0; i < getraenkeAngebot.length; i++) {
                System.out.println((i+1) + ". " + getraenkeAngebot[i].getName());
            }
            System.out.println("9. Ausschalten"); // Zusätzlicher Menüpunkt "Ausschalten".
            /*
            Mit "9. Ausschalten" setzt du voraus, dass es zukünftig maximal 8 Getränke geben wird.
            Ist hier natürlich möglich, würde ich aber vermutlich dynamischer gestalten.
             */

            // Aufforderung, eine Auswahl zu treffen
            System.out.print("Bitte Auswahl treffen (1 - " + getraenkeAngebot.length + ") oder Ausschalten: ");
            /*
            Da du im Switch-Block nicht "Ausschalten" prüfst, würde ich den Text eher so ändern:
            "Bitte Auswahl treffen (1 - " + getraenkeAngebot.length + ") oder \"9\" um auszuschalten: "
             */

            // Abfrage der Nutzereingabe
            // var consoleScanner = new Scanner(System.in);
            // int auswahl = (consoleScanner.nextInt());
            auswahl = consoleScanner.nextInt();

            switch(auswahl){
                case 1:
                    getraenkeAngebot[auswahl-1].getraenkAusgeben();
                    break;
                case 2:
                    getraenkeAngebot[auswahl-1].getraenkAusgeben();
                    break;
                case 3:
                    getraenkeAngebot[auswahl-1].getraenkAusgeben();
                    break;
                case 4:
                    getraenkeAngebot[auswahl-1].getraenkAusgeben();
                    break;
                case 5:
                    getraenkeAngebot[auswahl-1].getraenkAusgeben();
                    break;
                case 9:
                    statusAuswahl = false;
                    break;
                default:
                    System.out.println("Getränk nicht verfügbar!");
                    break;  /* Im Default-Block brauchst du kein break mehr, weil es so oder so nach dem switch-Block weiter geht */
            }
            /*
            So funktioniert der Switch-Block natürlich, allerdings hast du viel doppelten Code und es ist etwas
            unübersichtlich. Ich würde den Switch-Block daher eher so schreiben:

            // Übersichtlicher, aber immer noch etwas lang (vor allem musst du dadurch immer an das "break" denken)
            switch (auswahl) {
                case 1, 2, 3, 4, 5:
                    getraenkeAngebot[auswahl-1].getraenkAusgeben();
                    break;
                case 9:
                    statusAuswahl = false;
                    break;
                default:
                    System.out.println("Getränk nicht verfügbar");
            }

            // Mit Lambda-Ausdrücken:
            switch (auswahl) {
                case 1, 2, 3, 4, 5 -> getraenkeAngebot[auswahl - 1].getraenkAusgeben();
                case 9 -> statusAuswahl = false;
                default -> System.out.println("Getränk nicht verfügbar");
            }

            Zusätzlich bist du einerseits (z. B. mit "getraenkeAngebot.length") dynamisch, andererseits
            legst du dich mit den case-Blöcken ganz fix auf 5 Getränke fest. Ich würde daher versuchen den
            Switch-Block ebenfalls dynamisch zu gestalten.
             */

            // Zusammenfassung:
            General.divider();
            System.out.println("Bisher zubereitete Getränke an dieser Maschine: " + Getraenk.getAnzahlBezuege() + " Stk.");
            General.divider();

            /*
            Zur besseren Übersichtlichkeit/Trennung der einzelnen Bestellvorgänge würde ich hier noch eine Leerzeile
            einfügen:

            System.out.println();
             */
        }
        consoleScanner.close();
    }
}