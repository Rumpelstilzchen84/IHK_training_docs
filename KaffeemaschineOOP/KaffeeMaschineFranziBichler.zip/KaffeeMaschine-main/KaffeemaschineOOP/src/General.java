/**
 * @author: Philip Kottmann
 * @Datum: 24.3.2025
 * @Inhalt: Klasse "General" für allgemeine Dinge wie Zeilentrenner etc.
 */
public class General {

    public static void divider(){
        for (int i = 0; i < 21; i++) {
            System.out.print("=+");
        }
        System.out.println();
    }

    /*
    Nach Java-Namenskonvention sollten Klassen als Substantive (Nomen) benannt werden.
    Das machst du hier auch.

    Methoden sollten stattdessen als Verben oder Verbphrasen benannt werden. Mit "divider()" nutzt du hier aber ein
    Substantiv. Wenn ich "divider" lese, würde ich daher als Leser eher auf eine Klasse schließen,
    anstatt es als Methode zu verstehen.

    Klassen wie "General", "Allgemeines", "Utilities", "...Util", ... solltest du, wenn möglich, vermeiden.
    Solche Bezeichner sind so gut wie immer nichtssagend und tragen beim Lesen des Codes nicht zum Verständnis bei.
    Es ist immer besser "sprechende" Klassen zu verwenden. Mache im Zweifel lieber mehrere kleine sprechende Klassen.

    Bisher macht "General" nur eine Sache, die ohne großen Aufwand "sprechend" umgesetzt werden könnte.
    Wenn du die Klasse in "Trennlinie" umbenennst und die Methode in "ausgeben",
    umgehst du dadurch einerseits das unschöne "General" und andererseits wird die main-Methode deutlich verständlicher.
    Wie liest sich "General.divider()" im Gegensatz zu "Trennlinie.ausgeben()"?
     */
}