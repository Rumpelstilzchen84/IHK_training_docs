# IHK training documents
### Playground for IHK training course 3380
---

## Python projects
### nothing there yet - will be added soon ;)


## Java projects
### KaffeemaschineOOP:
+ Menu to choose from various coffee types
+ Menu item to switch off the coffee maker